import java.util.Scanner;
class multi
{
    public static void main(String[] args) 
    {
        int i;
        Scanner in= new Scanner(System.in);

        System.out.print("Enter the number to find multiples:");
        int a= in.nextInt();
        for(i=0;i<=10;i++)
        {
            System.out.println(a+"X"+i+" "+"="+" "+a*i);
        }
    }
}