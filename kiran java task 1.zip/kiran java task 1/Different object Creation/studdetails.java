import java.io.Serializable;
public class studdetails implements Serializable
{
    int i;  
 String string;  

public studdetails(int i, String string) 
{
    this.i = i;  
    this.string = string;  
}
}
